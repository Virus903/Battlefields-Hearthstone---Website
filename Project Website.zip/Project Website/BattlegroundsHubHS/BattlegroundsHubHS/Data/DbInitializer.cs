﻿using BattlegroundsHubHS.Models.Entities;
using BattlegroundsHubHS.Models.Enums;

namespace BattlegroundsHubHS.Data
{
    public static class DbInitializer
    {
        public static async Task InitializeAsync(AppDbContext context)
        {
            // ============================================================
            // 1. ТИПЫ КАРТ (CardTypes)
            // ============================================================
            if (!context.CardTypes.Any())
            {
                var cardTypes = new List<CardType>
                {
                    new() { Name = "Battlecry", NameRu = "Боевой клич", Description = "Эффект срабатывает один раз, когда карта разыгрывается из руки на поле.", SortOrder = 1 },
                    new() { Name = "Deathrattle", NameRu = "Предсмертный хрип", Description = "Эффект срабатывает когда карта умирает (в бою или при продаже).", SortOrder = 2 },
                    new() { Name = "Taunt", NameRu = "Провокация", Description = "Существо обязательно атакуют первым, если у противника есть провокация.", SortOrder = 3 },
                    new() { Name = "Divine Shield", NameRu = "Божественный щит", Description = "Существо игнорирует первый полученный урон.", SortOrder = 4 },
                    new() { Name = "Poisonous", NameRu = "Яд", Description = "Существо убивает любого врага одним ударом.", SortOrder = 5 },
                    new() { Name = "Venomous", NameRu = "Токсичность", Description = "Уничтожает первое существо, которому наносит урон.", SortOrder = 6 },
                    new() { Name = "Reborn", NameRu = "Перерождение", Description = "Существо возвращается к жизни один раз после смерти с 1 здоровьем.", SortOrder = 7 },
                    new() { Name = "Magnetic", NameRu = "Магнетизм", Description = "Механизм можно прикрепить к другому механизму, передавая свои характеристики.", SortOrder = 8 },
                    new() { Name = "Aura Buff", NameRu = "Массовый бафф", Description = "Даёт бонус всем существам определённого типа или на поле.", SortOrder = 9 },
                    new() { Name = "Blood Gem", NameRu = "Кровавый самоцвет", Description = "Временное заклинание, которое даёт +1/+1 существу.", SortOrder = 10 },
                    new() { Name = "Tavern Spell", NameRu = "Заклинание таверны", Description = "Карты, которые при розыгрыше дают заклинание.", SortOrder = 11 },
                    new() { Name = "Economy", NameRu = "Экономия", Description = "Даёт золото, монетки или скидку на покупку.", SortOrder = 12 },
                    new() { Name = "Summon", NameRu = "Призыв", Description = "Создаёт других существ (токенов).", SortOrder = 13 },
                    new() { Name = "Multiplier", NameRu = "Удвоитель", Description = "Усиливает другие эффекты (Бранн, Тит, Драккари).", SortOrder = 14 },
                    new() { Name = "Control", NameRu = "Контроль", Description = "Уничтожает врагов или наносит урон по всем.", SortOrder = 15 },
                    new() { Name = "End of Turn", NameRu = "Конец хода", Description = "Эффект срабатывает в конце хода.", SortOrder = 16 },
                    new() { Name = "Start of Combat", NameRu = "Начало боя", Description = "Эффект срабатывает в начале боя.", SortOrder = 17 }
                };
                await context.CardTypes.AddRangeAsync(cardTypes);
                Console.WriteLine($"✅ Добавлено {cardTypes.Count} типов карт");
            }

            // ============================================================
            // 2. ГЕРОИ (Heroes) — 1 тестовый герой
            // ============================================================
            if (!context.Heroes.Any())
            {
                var heroes = new List<Hero>
                {
                    new()
                    {
                        DbfId = 57944,
                        Name = "А.Ф.Ка",
                        ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/a0627a836a35eb9fd9c418c351a5ce9d8628f65ed6aa1f3b004607b70429724b.png",
                        HeroPower = "Бери и беги",
                        HeroPowerDescription = "Пропускает 1 и 2 ход, затем получает две карты 3 уровня.",
                        Armor = 15,
                        Tier = HeroTier.A
                    }
                };
                await context.Heroes.AddRangeAsync(heroes);
                Console.WriteLine($"✅ Добавлено {heroes.Count} героев");
            }

            // ============================================================
            // 3. МИНЬОНЫ (Minions) — 7 миньонов из сборки
            // ============================================================
            if (!context.Minions.Any())
            {
                var minions = new List<Minion>
                {
                    new() { DbfId = 59670, Name = "Заклинатель гнева", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/428b5403baac53e2ac0c2d8abe1cbc32efea127b303e37c3c3e610110df23260.png", TavernTier = 1, Type = MinionType.Demon, Attack = 1, Health = 3, Effect = "После того как вы разыгрываете демона, наносит 1 ед. урона вашему герою и получает +2/+2.", Rarity = CardRarity.Common },
                    new() { DbfId = 100949, Name = "Дирижер душ", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/b75f1fb730bf95aa3900e5e80683c00d05d3431ab54dfb9dc1d6fb3dd0eb471e.png", TavernTier = 2, Type = MinionType.Demon, Attack = 2, Health = 4, Effect = "После того как ваш герой получает урон, восстанавливает 2 ед. здоровья вашему герою.", Rarity = CardRarity.Rare },
                    new() { DbfId = 101556, Name = "Вампирическая гончая Скверны", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/83fe1a701fb33a18b23e22b3a448ee952c92102ee2e72788e15e3f7f5da5e59a.png", TavernTier = 3, Type = MinionType.Demon, Attack = 3, Health = 3, Effect = "Это существо покупается за здоровье, а не за золото.", Rarity = CardRarity.Rare },
                    new() { DbfId = 99228, Name = "Тихондрий", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/d31d10d59024d80f6edb9d2cab7f9966a66f7f526b2d6fc0f5d8653d68a91eed.png", TavernTier = 5, Type = MinionType.Demon, Attack = 4, Health = 8, Effect = "Когда демон получает урон, даёт +2/+2 другому случайному демону.", Rarity = CardRarity.Epic },
                    new() { DbfId = 72060, Name = "Ненасытный ур'зул", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/b5d95cb053e4c9bcdb33945badd99962c53d2a3c087f2d0e9d3119059c7dba18.png", TavernTier = 5, Type = MinionType.Demon, Attack = 3, Health = 3, Effect = "В конце вашего хода съедает существо в таверне и получает его характеристики.", Rarity = CardRarity.Epic },
                    new() { DbfId = 120299, Name = "Кудесник Скверны", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/3775202fe3488efce156425be189ad8e5e1f0b6cb534db99820c38e18e6ee986.png", TavernTier = 5, Type = MinionType.Demon, Attack = 3, Health = 6, Effect = "Боевой клич: уничтожает случайное существо у противника.", Rarity = CardRarity.Epic },
                    new() { DbfId = 72067, Name = "Голодающий сквернотопырь", ImageUrl = "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/698f79cce1c0ab31a002df5a19c4217b7c7ff4a3f13c8a8ad9ae0144d4cf0227.png", TavernTier = 6, Type = MinionType.Demon, Attack = 4, Health = 4, Effect = "В конце вашего хода даёт вашим демонам +2/+2.", Rarity = CardRarity.Legendary }
                };
                await context.Minions.AddRangeAsync(minions);
                Console.WriteLine($"✅ Добавлено {minions.Count} миньонов");
            }

            // ============================================================
            // 4. СБОРКИ (Builds) — 1 сборка из 7 миньонов
            // ============================================================
            if (!context.Builds.Any())
            {
                var minionIds = new List<int> { 59670, 100949, 101556, 99228, 72060, 120299, 72067 };
                var minionNames = new List<string>
                {
                    "Заклинатель гнева",
                    "Дирижер душ",
                    "Вампирическая гончая Скверны",
                    "Тихондрий",
                    "Ненасытный ур'зул",
                    "Кудесник Скверны",
                    "Голодающий сквернотопырь"
                };
                var minionImageUrls = new List<string>
                {
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/428b5403baac53e2ac0c2d8abe1cbc32efea127b303e37c3c3e610110df23260.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/b75f1fb730bf95aa3900e5e80683c00d05d3431ab54dfb9dc1d6fb3dd0eb471e.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/83fe1a701fb33a18b23e22b3a448ee952c92102ee2e72788e15e3f7f5da5e59a.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/d31d10d59024d80f6edb9d2cab7f9966a66f7f526b2d6fc0f5d8653d68a91eed.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/b5d95cb053e4c9bcdb33945badd99962c53d2a3c087f2d0e9d3119059c7dba18.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/3775202fe3488efce156425be189ad8e5e1f0b6cb534db99820c38e18e6ee986.png",
                    "https://d15f34w2p8l1cc.cloudfront.net/hearthstone/698f79cce1c0ab31a002df5a19c4217b7c7ff4a3f13c8a8ad9ae0144d4cf0227.png"
                };

                var builds = new List<Build>
                {
                    new()
                    {
                        Name = "Чистые демоны",
                        Description = "Классическая сборка демонов с самоповреждением и усилением.",
                        Strategy = "1) Найди Заклинателя гнева на 1 уровне. 2) Добавь Дирижёра душ для исцеления. 3) На 3 уровне возьми Вампирическую гончую Скверны. 4) На 5 уровне ищи Тихондрия, Ненасытного ур'зула и Кудесника Скверны. 5) На 6 уровне заверши сборку Голодающим сквернотопырем.",
                        Strengths = "Огромные характеристики, устойчивость к контролю, масштабирование каждым ходом.",
                        Weaknesses = "Уязвимость к яду, медленный старт, зависимость от ключевых карт 5 уровня.",
                        Tier = 1,
                        Category = "Чистые",
                        MainTribe = MinionType.Demon,
                        IsHybrid = false,
                        SecondaryTribe = "",
                        MinionIds = minionIds,
                        MinionNames = minionNames,
                        MinionImageUrls = minionImageUrls
                    }
                };

                await context.Builds.AddRangeAsync(builds);
                Console.WriteLine($"✅ Добавлено {builds.Count} сборок");
            }

            // ============================================================
            // 5. СОВЕТЫ (Tips)
            // ============================================================
            if (!context.Tips.Any())
            {
                var tips = new List<Tip>
                {
                    new() { Title = "Правило апов таверны", Content = "Ход 2 → ап до 2 уровня, ход 4 → ап до 3, ход 6 → ап до 4, ход 8-9 → ап до 5, ход 10+ → ап до 6", Category = "Стратегия", Priority = 10, Section = "Ранняя игра", IsDuos = false },
                    new() { Title = "Первый ход: что покупать", Content = "Бери самую сильную карту по статам. Если две одинаковые — бери обе.", Category = "Новичкам", Priority = 10, Section = "Ранняя игра", IsDuos = false },
                    new() { Title = "Хрономальные карты 3 уровня", Content = "На 6 ходу появляются хрономальные карты за 2 монеты. Вестник Вечности — лучший универсальный выбор.", Category = "Стратегия", Priority = 9, Section = "Средняя игра", IsDuos = false },
                    new() { Title = "Хрономальные карты 5 уровня", Content = "На 9 ходу дают хрономальные карты 5 уровня. Бронзовый хранитель даёт +5/+5 и провокацию.", Category = "Стратегия", Priority = 9, Section = "Поздняя игра", IsDuos = false },
                    new() { Title = "Что делать, если не идут карты", Content = "Не паникуй. Бери универсалов (Бранн, Тит, Амальгама). Меняй тип или строй гибрид.", Category = "Новичкам", Priority = 8, Section = "Общее", IsDuos = false }
                };
                await context.Tips.AddRangeAsync(tips);
                Console.WriteLine($"✅ Добавлено {tips.Count} советов");
            }

            await context.SaveChangesAsync();
            Console.WriteLine("🎉 Инициализация базы данных завершена!");
        }
    }
}