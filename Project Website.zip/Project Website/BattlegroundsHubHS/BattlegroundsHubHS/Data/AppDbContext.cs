﻿using Microsoft.EntityFrameworkCore;
using BattlegroundsHubHS.Models.Entities;
using System.Text.Json;

namespace BattlegroundsHubHS.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // ============================================================
        // ОСНОВНЫЕ ТАБЛИЦЫ
        // ============================================================
        public DbSet<Hero> Heroes { get; set; }
        public DbSet<Minion> Minions { get; set; }
        public DbSet<Spell> Spells { get; set; }
        public DbSet<Quest> Quests { get; set; }
        public DbSet<Reward> Rewards { get; set; }
        public DbSet<Anomaly> Anomalies { get; set; }
        public DbSet<Accessory> Accessories { get; set; }
        public DbSet<Chronomaly> Chronomalies { get; set; }
        public DbSet<ChronoSpell> ChronoSpells { get; set; }

        // ============================================================
        // НОВЫЕ ТАБЛИЦЫ
        // ============================================================
        public DbSet<CardType> CardTypes { get; set; }     // Типы карт (справочник)
        public DbSet<Build> Builds { get; set; }           // Сборки (7 карт)
        public DbSet<Tip> Tips { get; set; }               // Советы по игре

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ============================================================
            // СВЯЗИ (FOREIGN KEYS)
            // ============================================================

            // Настройка связи Quest -> Reward (необязательная связь)
            modelBuilder.Entity<Quest>()
                .HasOne(q => q.Reward)
                .WithMany()
                .HasForeignKey(q => q.RewardId)
                .OnDelete(DeleteBehavior.SetNull);

            // ============================================================
            // ИНДЕКСЫ ДЛЯ БЫСТРОГО ПОИСКА
            // ============================================================

            // Существующие индексы
            modelBuilder.Entity<Minion>()
                .HasIndex(m => m.TavernTier);

            modelBuilder.Entity<Minion>()
                .HasIndex(m => m.Type);

            modelBuilder.Entity<Hero>()
                .HasIndex(h => h.Tier);

            modelBuilder.Entity<Spell>()
                .HasIndex(s => s.TavernTier);

            // ============================================================
            // НОВЫЕ ИНДЕКСЫ
            // ============================================================

            // Индексы для сборок (Builds)
            modelBuilder.Entity<Build>()
                .HasIndex(b => b.MainTribe);

            modelBuilder.Entity<Build>()
                .HasIndex(b => b.Tier);

            modelBuilder.Entity<Build>()
                .HasIndex(b => b.Category);

            // Индексы для советов (Tips)
            modelBuilder.Entity<Tip>()
                .HasIndex(t => t.Category);

            modelBuilder.Entity<Tip>()
                .HasIndex(t => t.IsDuos);

            modelBuilder.Entity<Tip>()
                .HasIndex(t => t.Priority);

            // Индекс для типов карт (CardTypes)
            modelBuilder.Entity<CardType>()
                .HasIndex(c => c.SortOrder);

            // ============================================================
            // КОНФИГУРАЦИЯ JSON ПОЛЕЙ ДЛЯ СБОРОК (Builds)
            // ============================================================

            // Настройка MinionIds (List<int> → JSON)
            modelBuilder.Entity<Build>()
                .Property(b => b.MinionIds)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                    v => JsonSerializer.Deserialize<List<int>>(v, (JsonSerializerOptions?)null) ?? new List<int>()
                );

            // Настройка MinionNames (List<string> → JSON)
            modelBuilder.Entity<Build>()
                .Property(b => b.MinionNames)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                    v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions?)null) ?? new List<string>()
                );

            // Настройка MinionImageUrls (List<string> → JSON)
            modelBuilder.Entity<Build>()
                .Property(b => b.MinionImageUrls)
                .HasConversion(
                    v => JsonSerializer.Serialize(v, (JsonSerializerOptions?)null),
                    v => JsonSerializer.Deserialize<List<string>>(v, (JsonSerializerOptions?)null) ?? new List<string>()
                );
        }
    }
}