﻿namespace BattlegroundsHubHS.Models.Entities
{
    /// Совет — помощь игрокам
    public class Tip
    {
        public int Id { get; set; }
        public string Title { get; set; } = "";              // Заголовок совета
        public string Content { get; set; } = "";            // Текст совета
        public string Category { get; set; } = "";           // "Новичкам", "Стратегия", "Мета", "Герои", "Соло", "Дуо"
        public int Priority { get; set; } = 1;               // Важность (1-10)
        public string ImageUrl { get; set; } = "";           // Иллюстрация к совету
        public string Section { get; set; } = "";            // "Ранняя игра", "Средняя игра", "Поздняя игра", "Общее"
        public bool IsDuos { get; set; } = false;            // Совет для режима дуо?
    }
}