﻿namespace BattlegroundsHubHS.Models.Entities
{
    /// Тип карты — справочник для фильтрации
    public class CardType
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";        // "Battlecry", "Deathrattle", "Taunt" и т.д.
        public string NameRu { get; set; } = "";      // "Боевой клич", "Предсмертный хрип", "Провокация"
        public string Description { get; set; } = ""; // Описание механики
        public string IconUrl { get; set; } = "";     // Иконка для UI
        public int SortOrder { get; set; }            // Порядок отображения
    }
}