﻿using BattlegroundsHubHS.Models.Enums;
using System.Text.Json.Serialization;

namespace BattlegroundsHubHS.Models.Entities
{
    public class Build
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public string Strategy { get; set; } = "";
        public string Strengths { get; set; } = "";
        public string Weaknesses { get; set; } = "";
        public string ScreenshotUrl { get; set; } = "";
        public int Tier { get; set; }
        public MinionType? MainTribe { get; set; }
        public bool IsHybrid { get; set; }
        public string SecondaryTribe { get; set; } = "";
        public string Category { get; set; } = "";

        // Важно: указываем тип колонки JSON и инициализируем значением по умолчанию
        public List<int> MinionIds { get; set; } = new List<int>();
        public List<string> MinionNames { get; set; } = new List<string>();
        public List<string> MinionImageUrls { get; set; } = new List<string>();
    }
}