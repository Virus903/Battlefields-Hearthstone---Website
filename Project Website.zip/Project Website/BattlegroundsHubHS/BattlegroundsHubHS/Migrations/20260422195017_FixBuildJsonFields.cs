﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BattlegroundsHubHS.Migrations
{
    /// <inheritdoc />
    public partial class FixBuildJsonFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ImageUrl",
                table: "Builds");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ImageUrl",
                table: "Builds",
                type: "TEXT",
                nullable: false,
                defaultValue: "");
        }
    }
}
