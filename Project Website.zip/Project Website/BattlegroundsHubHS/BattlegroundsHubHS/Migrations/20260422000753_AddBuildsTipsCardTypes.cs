﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BattlegroundsHubHS.Migrations
{
    /// <inheritdoc />
    public partial class AddBuildsTipsCardTypes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MainType",
                table: "Builds",
                newName: "MainTribe");

            migrationBuilder.AddColumn<bool>(
                name: "IsDuos",
                table: "Tips",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Section",
                table: "Tips",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "Builds",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "IsHybrid",
                table: "Builds",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "MinionIds",
                table: "Builds",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "MinionNames",
                table: "Builds",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SecondaryTribe",
                table: "Builds",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "CardTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    NameRu = table.Column<string>(type: "TEXT", nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: false),
                    IconUrl = table.Column<string>(type: "TEXT", nullable: false),
                    SortOrder = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CardTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tips_Category",
                table: "Tips",
                column: "Category");

            migrationBuilder.CreateIndex(
                name: "IX_Tips_IsDuos",
                table: "Tips",
                column: "IsDuos");

            migrationBuilder.CreateIndex(
                name: "IX_Tips_Priority",
                table: "Tips",
                column: "Priority");

            migrationBuilder.CreateIndex(
                name: "IX_Builds_Category",
                table: "Builds",
                column: "Category");

            migrationBuilder.CreateIndex(
                name: "IX_Builds_MainTribe",
                table: "Builds",
                column: "MainTribe");

            migrationBuilder.CreateIndex(
                name: "IX_Builds_Tier",
                table: "Builds",
                column: "Tier");

            migrationBuilder.CreateIndex(
                name: "IX_CardTypes_SortOrder",
                table: "CardTypes",
                column: "SortOrder");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CardTypes");

            migrationBuilder.DropIndex(
                name: "IX_Tips_Category",
                table: "Tips");

            migrationBuilder.DropIndex(
                name: "IX_Tips_IsDuos",
                table: "Tips");

            migrationBuilder.DropIndex(
                name: "IX_Tips_Priority",
                table: "Tips");

            migrationBuilder.DropIndex(
                name: "IX_Builds_Category",
                table: "Builds");

            migrationBuilder.DropIndex(
                name: "IX_Builds_MainTribe",
                table: "Builds");

            migrationBuilder.DropIndex(
                name: "IX_Builds_Tier",
                table: "Builds");

            migrationBuilder.DropColumn(
                name: "IsDuos",
                table: "Tips");

            migrationBuilder.DropColumn(
                name: "Section",
                table: "Tips");

            migrationBuilder.DropColumn(
                name: "Category",
                table: "Builds");

            migrationBuilder.DropColumn(
                name: "IsHybrid",
                table: "Builds");

            migrationBuilder.DropColumn(
                name: "MinionIds",
                table: "Builds");

            migrationBuilder.DropColumn(
                name: "MinionNames",
                table: "Builds");

            migrationBuilder.DropColumn(
                name: "SecondaryTribe",
                table: "Builds");

            migrationBuilder.RenameColumn(
                name: "MainTribe",
                table: "Builds",
                newName: "MainType");
        }
    }
}
