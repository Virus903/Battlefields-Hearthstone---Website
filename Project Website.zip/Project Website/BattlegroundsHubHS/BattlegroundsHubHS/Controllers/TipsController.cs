﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BattlegroundsHubHS.Data;
using BattlegroundsHubHS.Models.Entities;

namespace BattlegroundsHubHS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TipsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TipsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tip>>> GetAll()
        {
            var tips = await _context.Tips
                .OrderByDescending(t => t.Priority)
                .ThenBy(t => t.Title)
                .ToListAsync();
            return Ok(tips);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Tip>> GetById(int id)
        {
            var tip = await _context.Tips.FindAsync(id);
            if (tip == null) return NotFound();
            return Ok(tip);
        }

        [HttpGet("category/{category}")]
        public async Task<ActionResult<IEnumerable<Tip>>> GetByCategory(string category)
        {
            var tips = await _context.Tips
                .Where(t => t.Category == category)
                .OrderByDescending(t => t.Priority)
                .ToListAsync();
            return Ok(tips);
        }
    }
}