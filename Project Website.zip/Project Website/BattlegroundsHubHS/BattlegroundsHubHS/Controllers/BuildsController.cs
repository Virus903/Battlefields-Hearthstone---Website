﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BattlegroundsHubHS.Data;
using BattlegroundsHubHS.Models.Entities;

namespace BattlegroundsHubHS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BuildsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BuildsController(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Получить все сборки
        /// </summary>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Build>>> GetAll()
        {
            try
            {
                // 1. Сначала просто получим все сборки без сортировки
                var builds = await _context.Builds.ToListAsync();

                // 2. Диагностика: выведем в консоль каждую сборку
                foreach (var build in builds)
                {
                    Console.WriteLine($"=== Сборка ID={build.Id}, Name={build.Name ?? "null"} ===");

                    // Проверяем каждое поле
                    if (build.MinionIds == null)
                        Console.WriteLine("  ❌ MinionIds = null");
                    else
                        Console.WriteLine($"  ✅ MinionIds count = {build.MinionIds.Count}");

                    if (build.MinionNames == null)
                        Console.WriteLine("  ❌ MinionNames = null");
                    else
                        Console.WriteLine($"  ✅ MinionNames count = {build.MinionNames.Count}");

                    if (build.MinionImageUrls == null)
                        Console.WriteLine("  ❌ MinionImageUrls = null");
                    else
                        Console.WriteLine($"  ✅ MinionImageUrls count = {build.MinionImageUrls.Count}");
                }

                // 3. Теперь применяем сортировку (уже в памяти, чтобы избежать ошибки EF)
                var sortedBuilds = builds
                    .OrderBy(b => b.Tier)
                    .ThenBy(b => b.Name)
                    .ToList();

                // 4. Исправляем null коллекции
                foreach (var build in sortedBuilds)
                {
                    if (build.MinionIds == null) build.MinionIds = new List<int>();
                    if (build.MinionNames == null) build.MinionNames = new List<string>();
                    if (build.MinionImageUrls == null) build.MinionImageUrls = new List<string>();
                }

                return Ok(sortedBuilds);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка в GetAll: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                return StatusCode(500, new { error = ex.Message, stack = ex.StackTrace });
            }
        }
    }
}