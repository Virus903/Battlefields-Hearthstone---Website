﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BattlegroundsHubHS.Data;
using BattlegroundsHubHS.Models.Entities;

namespace BattlegroundsHubHS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CardTypesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CardTypesController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CardType>>> GetAll()
        {
            var types = await _context.CardTypes
                .OrderBy(t => t.SortOrder)
                .ToListAsync();
            return Ok(types);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CardType>> GetById(int id)
        {
            var type = await _context.CardTypes.FindAsync(id);
            if (type == null) return NotFound();
            return Ok(type);
        }
    }
}